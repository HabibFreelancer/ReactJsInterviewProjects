

const ProductDetails = ()=>{

    return(
        <div>
            <h1> Product Details Page </h1>
        </div>
    )
}

export default ProductDetails;