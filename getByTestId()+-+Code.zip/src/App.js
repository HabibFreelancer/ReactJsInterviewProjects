import React,{useState} from 'react';
import './App.css';
import Product from './Components/Product/Product';
import ValidPriceList from './Components/Product/ValidPriceList';

function App() {
const pObj=[
  {pName:'Apple',min:15,max:20},
  {pName:'Banana',min:3,max:6},
  {pName:'Grapes',min:7,max:12},
  {pName:'Orange',min:11,max:14}
]
  const [products,setProducts]=useState(pObj);
  return (
    <div className="App">
      <ValidPriceList products={products}/>
        <Product products={products}/>
    </div>
  );
}

export default App;
