import React,{useState} from 'react';
const Product=(props)=>{
    const [msg,setMsg]=useState('Validation Message');
    const [currentSelection,setCurrentSelection]=useState({});
    const [inputPrice,setInputPrice]=useState(0);
    const setValues=(e)=>{
        console.log("Hi");
        let min = props.products.filter((obj)=>{
            return obj.pName == e.target.value
        })
        setCurrentSelection(min);

    }
    const onInputChange=(e)=>{
        setInputPrice(e.target.value)
    }
    const checkPrice=()=>{
        console.log(currentSelection);
        console.log(inputPrice);
        if(inputPrice< currentSelection[0].min){
            setMsg("Price too low");
        }else if(inputPrice> currentSelection[0].max){
            setMsg("Price too high");
        }else{
            setMsg("Valid price");
        }
    }
    return(
        <div>
            <hr/>
            <label>Select Product</label>
            <select onChange={setValues}>
            {
                props.products.map((product,index)=>{
                    return(
                        <option 
                        key={index}>
                            {product.pName}
                        </option>
                    )
                })
                
            }
            </select>
            
            <label>Enter Price</label>
            <input type="text" onChange={onInputChange}/>
            <button onClick={checkPrice}>Validate</button>
            <br/>

            <h3 data-testid="msg">{msg}</h3>
        </div>
    )
}
export default Product;