import React from 'react';
import {render,screen} from '@testing-library/react';
import Product from './Product';

const pObj=[
    {pName:'Apple',min:15,max:20},
    {pName:'Banana',min:3,max:6},
    {pName:'Grapes',min:7,max:12},
    {pName:'Orange',min:11,max:14}
]

test('Rendering of Validation Message Element', ()=>{
    render(<Product products={pObj}/>);
    const vElement = screen.getByTestId("msg");
    expect(vElement).toBeInTheDocument();
})