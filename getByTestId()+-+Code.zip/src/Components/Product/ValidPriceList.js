import React from 'react';
import './priceList.css';
const ValidPriceList=(props)=>{
    return(
        
<table>
            <tr>
                <th>Product</th>
                <th>Min. Price</th>
                <th>Max. Price</th>
            </tr>
            {
                props.products.map((product,index)=>{
                    return(
                        <tr>
                        <td>{product.pName}</td>
                        <td>{product.min}</td>
                        <td>{product.max}</td>
                        </tr>
                    )
                })
            }
</table>
    )
}

export default ValidPriceList;