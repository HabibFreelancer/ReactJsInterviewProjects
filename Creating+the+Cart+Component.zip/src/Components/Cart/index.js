

const Cart = ()=>{

    return(
        <div>
            <h1> The Cart Component </h1>
        </div>
    )
}

export default Cart;