import logo from './logo.svg';
import './App.css';
import TopNav from './Components/TopNav';

function App() {
  return (
    <div className="App">
      <TopNav/>
    </div>
  );
}

export default App;
