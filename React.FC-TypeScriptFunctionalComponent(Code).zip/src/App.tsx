import React from 'react';
import Product from './Product'
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
     <Product pCode={1} pName="Apple"/>
    </div>
  );
}

export default App;
