import React from 'react';

const TotalContext = React.createContext(0);

export default TotalContext; 