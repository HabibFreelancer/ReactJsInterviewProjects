

const FilledCart = ()=>{

    return(
        <div>
            <h1> The Filled Cart </h1>
        </div>
    )
}

export default FilledCart;