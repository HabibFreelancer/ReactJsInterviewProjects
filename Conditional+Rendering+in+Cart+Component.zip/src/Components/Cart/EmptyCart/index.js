

const EmptyCart = ()=>{

    return(
        <div>
            <h1> The Cart Is Empty </h1>
        </div>
    )
}

export default EmptyCart;