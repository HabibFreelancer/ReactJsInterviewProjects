import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <div className='header bg-dark'>
        <div className='row'>
          <div className='brand my-1'>
            <h1> eStore </h1>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
